<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StorageDetails extends Model
{

    protected $table = 'storage_information';
}
