<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\fileUploadRequest;
use Storage;
use App\Model\StorageDetails;
use App\Mail\SendFileUploadedMail;
use Mail;

class FileStoreController extends Controller
{
        
    /**
     * storeFile
     * Here fileUploadRequest validator will validate the file with validation rules
     * @param  mixed $request
     * @return void
     */

    public function storeFile(fileUploadRequest $request){
        /** Here i have used fake Laravel storage to attain the execution without aws s3 connection it should be removed when s3 connection established  **/
        Storage::fake('s3_upload');
        $fileName=$request->file('formFile')->getClientOriginalName();

        $filePath = 'uploads/'.$fileName;

        $fileRes =  Storage::disk('s3_upload')->put($filePath, file_get_contents($request->file('formFile')));

        if($fileRes){
            $insertResponse = StorageDetails::insert([
                'file_name'=>$fileName,
                'file_size'=>number_format($request->file('formFile')->getSize() / 1048576, 2),
                's3_object'=>$fileName
            ]);
            
            

            if($insertResponse){
                /** As of now the mail driver is set to log once after mail config it has to be removed */

                /** In order to test the execution the queue method is commented once after live we can enable queue method for better performance */
                // $queue_mail = (new SendFileUploadedMail($fileName))->onQueue('emails');
                // Mail::to(env('MailSendNotification'))->queue($queue_mail);

                Mail::to(env('MailSendNotification'))->send(new SendFileUploadedMail($fileName));
                return response('File Uploaded Successfully', 200);

            }
            return response('Failed to upload', 400);


        }

    }
}
