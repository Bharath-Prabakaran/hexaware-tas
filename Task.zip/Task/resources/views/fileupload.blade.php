<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>File Upload</title>  
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<style>
.fileupload{
    max-width:17%;
    font-size:14px;
}
.errorDetails{
color:red;
font-size:14px;
}
</style>

</head>
<body>
<form action="/fileUpload" method="POST" enctype="multipart/form-data">
    <div class="mb-3">
    <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />

    <label for="formFile" class="form-label">Upload File</label>
    <input class="form-control fileupload" type="file" name="formFile" id="formFile" accept=".doc,.pdf,.txt,.xml,.csv">
    <p class="errorDetails"></p>
    </div>
    <div class="mb-3">
    <input type="submit" value="Upload">
    </div>

    <div>
    Note: Only doc, pdf, xml, txt, csv format files are allowed.
    </div>
</form>
</body>
</html>



<script>
$("#formFile").change(function () {
    $(".errorDetails").html("");
    var fileExtension = ['doc', 'pdf', 'txt', 'xml', 'csv'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        $(".errorDetails").html("Only specific formats are allowed : "+fileExtension.join(', '));
        $("#formFile").val('');
    }else{
        const fileSize = (this.files[0].size / 1024 / 1024).toFixed(2);
        if(fileSize >10){
            $(".errorDetails").html("File Size should be less than 10MB");
        }
    }
});
</script>